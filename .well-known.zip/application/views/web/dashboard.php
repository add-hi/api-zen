
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>Dashboard</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item">Dashboard</div>
            </div>
          </div>

          <div class="section-body">
                    <div class="alert alert-info alert-has-icon">
                      <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
                      <div class="alert-body">
                        <div class="alert-title">Info</div>
                        to find and configure your api key, you can go to the profile menu
                      </div>
                    </div>
          </div>
        </section>
      </div>
      

    
<?php
$this->RenderScript[] = function() {
?>
      
<?php
}
?>